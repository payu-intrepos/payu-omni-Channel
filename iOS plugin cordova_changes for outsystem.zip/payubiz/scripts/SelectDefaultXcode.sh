# to make sure that any command that fails in turn return a non zero status and does not continue further

set -e

# get framework path from command line or use the current working directory as the path

if [ $# -eq 0 ] ; then		
FRAMEWORK_PATH=$(pwd)/PayUAssetLibraryKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUBizCoreKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUCheckoutProBaseKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUCheckoutProKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUCustomBrowser.xcframework/
FRAMEWORK_PATH=$(pwd)/PayULoggerKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUNetworkingKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUParamsKit.xcframework/
FRAMEWORK_PATH=$(pwd)/PayUUPICoreKit.xcframework/
FRAMEWORK_PATH=$(pwd)/SocketIO.xcframework/
FRAMEWORK_PATH=$(pwd)/Starscream.xcframework/
echo "Using the current working directory as the framework path which is $FRAMEWORK_PATH"
else
FRAMEWORK_PATH=$1
fi

#navigate to the module map

cd "$FRAMEWORK_PATH/Modules/"

#find xcode path and replace it with the default

DEFAULT_XCODE_PATH="$(xcode-select -p)"
IFS='/'
read -ra ARRAY <<< "$DEFAULT_XCODE_PATH"
XCODE_COMPONENT=${ARRAY[2]}
STRING_TO_BE_REPLACED="Xcode.app"
sed -i '' "s/$STRING_TO_BE_REPLACED/$XCODE_COMPONENT/g" module.modulemap
