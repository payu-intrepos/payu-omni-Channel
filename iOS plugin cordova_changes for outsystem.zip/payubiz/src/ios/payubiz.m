/********* payubiz.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>
#import <PayUCheckoutProKit/PayUCheckoutProKit.h>
#import <PayUCheckoutProBaseKit/PayUCheckoutProBaseKit.h>
#import <PayUParamsKit/PayUParamsKit.h>
#import <PayUBizCoreKit/PayUBizCoreKit.h>
@interface payubiz : CDVPlugin <PayUCheckoutProDelegate> {
  // Member variables go here.
    
}
@property (nonatomic,copy) void(^onCompletion)(NSDictionary<NSString *,NSString *> *);

- (void)checkOutPro:(CDVInvokedUrlCommand*)command;
- (void)setHash:(CDVInvokedUrlCommand*)command;
@end

@implementation payubiz

#pragma mark Helper Methods
static NSString* myAsyncCallbackId = nil;
NSString *commandName;
NSString *hashStringWithoutSalt;
- (void)checkOutPro:(CDVInvokedUrlCommand*)command
{
    myAsyncCallbackId = command.callbackId;
    int env = 1;
    NSString* amount = [command.arguments objectAtIndex:0];
    NSString* transactionId = [command.arguments objectAtIndex:1];
    NSNumber* isProd = [command.arguments objectAtIndex:2];
    if([isProd isEqual:@(YES)]){
        env = 0;
    }
    NSString* prodInfo = [command.arguments objectAtIndex:3];
    NSString* key = [command.arguments objectAtIndex:4];
    NSString* salt = [command.arguments objectAtIndex:5];
    NSString* phone = [command.arguments objectAtIndex:6];
    NSString* email = [command.arguments objectAtIndex:7];
    NSString* firstName = [command.arguments objectAtIndex:8];
    NSString* sUrl = [command.arguments objectAtIndex:9];
    NSString* fUrl = [command.arguments objectAtIndex:10];
    NSString* userCredentials = [command.arguments objectAtIndex:11];
    NSString* addParam1 = [command.arguments objectAtIndex:12];
    NSString* addParam2 = [command.arguments objectAtIndex:13];
    NSString* addParam3 = [command.arguments objectAtIndex:14];
    NSString* addParam4 = [command.arguments objectAtIndex:15];
    NSString* addParam5 = [command.arguments objectAtIndex:16];
    NSString* addParam6 = [command.arguments objectAtIndex:17];
    NSString* addParam7 = [command.arguments objectAtIndex:18];
    
    PayUPaymentParam *paymentParam = [[PayUPaymentParam alloc] initWithKey:key
                                                             transactionId:transactionId
                                                                    amount:amount
                                                               productInfo:prodInfo
                                                                 firstName:firstName
                                                                     email:email
                                                                     phone:phone
                                                                      surl:sUrl
                                                                      furl:fUrl
                                                               environment:env];
    paymentParam.userCredential = userCredentials;
    paymentParam.additionalParam = [[NSDictionary alloc] initWithObjectsAndKeys:
                                       addParam1, PaymentParamConstant.udf1,
                                       addParam2, PaymentParamConstant.udf2,
                                       addParam3, PaymentParamConstant.udf3,
                                       addParam4, PaymentParamConstant.udf4,
                                       addParam5, PaymentParamConstant.udf5,
                                       addParam6, HashConstant.vasForMobileSDK,
                                       addParam7, HashConstant.paymentRelatedDetailForMobileSDK,
                                       nil];
    PayUCheckoutProConfig *config = [PayUCheckoutProConfig new];
    //config.merchantName = @"Umang Enterprises";
    config.autoSelectOtp = true;
    config.merchantResponseTimeout = 8;
    config.surePayCount = 2;
  
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT];
        [pluginResult setKeepCallbackAsBool:YES];
    UIViewController *controller = [UIApplication sharedApplication].keyWindow.rootViewController;
    [PayUCheckoutPro openOn:controller paymentParam:paymentParam config:config delegate:self];
       
}
- (void)onPaymentSuccessWithResponse:(id _Nullable)response {
    // handle success scenario
    [self.commandDelegate runInBackground:^{
        CDVPluginResult *result = [CDVPluginResult
               resultWithStatus:CDVCommandStatus_OK
            messageAsDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                                  @"0",@"payUResponseCode",
                                 response,@"payUResponse",nil]];
        [self.commandDelegate sendPluginResult:result callbackId:myAsyncCallbackId];
    }];
}

- (void)onPaymentFailureWithResponse:(id _Nullable)response {
    // handle failure scenario
    [self.commandDelegate runInBackground:^{
        CDVPluginResult *result = [CDVPluginResult
               resultWithStatus:CDVCommandStatus_ERROR
            messageAsDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                 @"1",@"payUResponseCode",
                                 response,@"payUResponse",nil]];
        [self.commandDelegate sendPluginResult:result callbackId:myAsyncCallbackId];
    }];
}

- (void)onError:(NSError * _Nullable)error {
    // handle error scenario
   
        CDVPluginResult *result = [CDVPluginResult
               resultWithStatus:CDVCommandStatus_ERROR
            messageAsDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                 @"3", @"payUResponseCode",
                                 error.localizedDescription, @"payUResponse",nil]];
        [self.commandDelegate sendPluginResult:result callbackId:myAsyncCallbackId];

}

- (void)onPaymentCancelWithIsTxnInitiated:(BOOL)isTxnInitiated {
    // handle txn cancelled scenario
    // isTxnInitiated == YES, means user cancelled the txn when on reaching bankPage
    // isTxnInitiated == NO, means user cancelled the txn before reaching the bankPage
//
    [self.commandDelegate runInBackground:^{
      
        CDVPluginResult *result = [CDVPluginResult
               resultWithStatus:CDVCommandStatus_ERROR
            messageAsDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                 @"2",@"payUResponseCode",
                                 isTxnInitiated, @"payUResponse", nil]];
        [result setKeepCallback:[NSNumber numberWithBool:YES]];
        [self.commandDelegate sendPluginResult:result callbackId:myAsyncCallbackId];
    }];
}

- (void)generateHashFor:(NSDictionary<NSString *,NSString *> * _Nonnull)param onCompletion:(void (^ _Nonnull)(NSDictionary<NSString *,NSString *> * _Nonnull))onCompletion {
    commandName = [param objectForKey:HashConstant.hashName];
    hashStringWithoutSalt    = [param objectForKey:HashConstant.hashString];
     
        _onCompletion = onCompletion;
        [self.commandDelegate runInBackground:^{
        CDVPluginResult *result = [CDVPluginResult
               resultWithStatus:CDVCommandStatus_OK
            messageAsDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                 @"4",@"payUResponseCode",
                                 hashStringWithoutSalt, @"hashData",commandName, @"hashName", nil]];
        [result setKeepCallbackAsBool:YES];
        [self.commandDelegate sendPluginResult:result callbackId:myAsyncCallbackId];
    }];
}

- (void)setHash:(CDVInvokedUrlCommand*)command{
     NSString* hashName = [command.arguments objectAtIndex:0];
     NSString* hashValue = [command.arguments objectAtIndex:1];
     NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:hashValue, hashName, nil];
   _onCompletion(dict);
}
@end
