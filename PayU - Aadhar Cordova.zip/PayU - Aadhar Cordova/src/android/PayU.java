package cordova.plugin.payu;
import java.util.Map;
import java.util.HashMap;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import com.payphi.merchantsdk.PayPhiSdk;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.widget.Toast;
import android.util.Log;
import org.json.JSONArray;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
/**
 * This class echoes a string called from JavaScript.
 */
public class PayU extends CordovaPlugin implements PayPhiSdk.IAppInitializationListener {
    String result = "";
    String hashKey = "abc";
    Map<String, String> map = new HashMap<>();
    CallbackContext callbackContext;
    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if (action.equals("coolMethod")) {
            String message = args.getString(0);
            this.coolMethod(message, callbackContext);
            return true;
        }else if(action.equals("init")){
            String appID = args.getString(0);
            String mId = args.getString(1);
            boolean aggFlag = args.getBoolean(2);
            String env = args.getString(3);
            String aggMid = args.getString(4);
            String merchantName = args.getString(5);
            this.init(appID,mId,aggFlag,env,aggMid,merchantName,callbackContext);
            return true;
        }else if(action.equals("makePayment")){
            String amount = args.getString(0);
             String orderId = args.getString(1);
              String currencyCode = args.getString(2);
               
                String merchantId = args.getString(3);
                String secureToken = args.getString(4);
                 String CustomerEmailID = args.getString(5);
                   String MobileNo = args.getString(6);
                   String deviceId = args.getString(7);
                   String aggMerchantId = args.getString(8);
                   String addParam = args.getString(9);
                
                   this.makePayment(amount,orderId,currencyCode,merchantId,secureToken,CustomerEmailID,MobileNo,deviceId,aggMerchantId,addParam,callbackContext);
                   return true;

        }
        return false;
    }

    private void coolMethod(String message, CallbackContext callbackContext) {
        if (message != null && message.length() > 0) {
            callbackContext.success(message);
        } else {
            callbackContext.error("Expected one non-empty string argument.");
        }
    }
    private void init(String appId,String mId,boolean aggFlag,String env,String aggMid,String marchantName,CallbackContext callbackContext){
            PayPhiSdk.setEnv(env);
            if(aggFlag){
                PayPhiSdk.useAggregatorMID(this.cordova.getActivity().getApplicationContext());           
            }else{
            
            }
            PayPhiSdk.setMerchantName(this.cordova.getActivity().getApplicationContext(),marchantName,"NO");
            PayPhiSdk.setTransactionRestrictForConsumerNo(this.cordova.getActivity().getApplicationContext(),PayPhiSdk.YES,15);
            PayPhiSdk.setAppInfo(mId, appId, this.cordova.getActivity().getApplicationContext(), new PayPhiSdk.IAppInitializationListener() {
            @Override
            public void onSuccess(String status) {
              //  result = status;
               //  Toast.makeText(this.cordova.getActivity().getApplicationContext(), "In paraent home===" + status, Toast.LENGTH_LONG).show();
                callbackContext.success(status);
            }

            @Override
            public void onFailure(String errorCode) {
               //  result = errorCode;
                 //  Toast.makeText(this.cordova.getActivity().getApplicationContext(), "In paraent home===" + errorCode, Toast.LENGTH_LONG).show();
                 callbackContext.error(errorCode);
            }

        });

         //callbackContext.error(result);
    }
    private void makePayment(String amt,String orderId,String currencyCode,
     String merchantId,String secureToken, String CustomerEmailID,String MobileNo,String deviceId,String aggMerchantId,String addParam,CallbackContext callbackContext){

            map.put("Amount", amt);
            map.put("MerchantTxnNo", orderId);
            map.put("CurrencyCode", currencyCode);
            if(!aggMerchantId.equals("")){
                 map.put("MerchantID", "");
                 map.put("SecureToken", secureToken);
            }else{
                 map.put("MerchantID", merchantId);
                 map.put("SecureToken", secureToken);
            }
          
            map.put("CustomerEmailID", CustomerEmailID);
            map.put("InvoiceNo", orderId);
            map.put("MobileNo", MobileNo);
            map.put("DeviceID", deviceId);
            map.put("addlParam1", aggMerchantId);
            map.put("addlParam2", addParam);
            
           // Toast.makeText(this.cordova.getActivity().getApplicationContext(),getSecureToken(amt,currencyCode,merchantId,orderId),Toast.LENGTH_LONG).show();
             android.support.v4.app.Fragment fragment = PayPhiSdk.makePayment(this.cordova.getActivity().getApplicationContext(), map, PayPhiSdk.DIALOG, new PayPhiSdk.IAppPaymentResponseListenerEx() {

                @Override
                public void onPaymentResponse(int i, Map<String, String> map, Map<String, String> additionalInfoMap) {
                     if (i == -1) {
                        if(map.containsKey("txnResponseCode")) {
                            try {
                             JSONObject jsonObj = new JSONObject(map);
                             jsonObj.put("resultCode",Integer.toString(i));
                             callbackContext.success(jsonObj);
                             } catch (JSONException e) {
                                //some exception handler code.
                            }  
                        }else{
                            try {
                             JSONObject jsonObj = new JSONObject();
                             jsonObj.put("resultCode",Integer.toString(i));
                             callbackContext.success(jsonObj);
                              } catch (JSONException e) {
                                //some exception handler code.
                            }  
                        }
                    }else{
                         try {
                             JSONObject jsonObj = new JSONObject();
                             jsonObj.put("resultCode",Integer.toString(i));
                             callbackContext.success(jsonObj);
                               } catch (JSONException e) {
                                //some exception handler code.
                            } 
                    }
                }

                @Override
                public void onPaymentResponse(int resultCode, Map<String, String> map) {
                    //callbackContext.success(resultCode);
                }


            });
    }
 @Override
    public void onSuccess(String s) {

    }

    @Override
    public void onFailure(String s) {

    }


    private String generateHMAC(String message, String secretKey) {
        Mac sha256_HMAC;
        byte[] hashedBytes = null;
        try {
            sha256_HMAC = Mac.getInstance("HmacSHA256");
            SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
            sha256_HMAC.init(secret_key);

            hashedBytes = sha256_HMAC.doFinal(message.getBytes());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //Check here
        return bytesToHex(hashedBytes);
    }

    public static String bytesToHex(byte[] message) {
        StringBuffer stringBuffer = new StringBuffer();
        try {
            for (int i = 0; i < message.length; i++) {
                stringBuffer.append(Integer.toString((message[i] & 0xff) + 0x100, 16).substring(1));
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }


    private String getSecureToken(String amt,String currencyCode,String merchantId,String orderId) {
       // Toast.makeText(this.cordova.getActivity().getApplicationContext(),amt,Toast.LENGTH_LONG).show();
        DecimalFormat df = new DecimalFormat();
        df.setMinimumFractionDigits(2);
        Float f = Float.parseFloat(amt);
        df.format(f);
        amt = String.format("%.2f", f);

        String val = null;
       
          val = amt + currencyCode + merchantId + orderId;
        //val = "smsplus" + amt + currencyCode + orderId;
       
       // Toast.makeText(this.cordova.getActivity().getApplicationContext(),val,Toast.LENGTH_LONG).show();
        System.out.println("val "+val);
      //  String secureToken = generateHMAC(val, "0f7c5df1a9b94d90ae09d6010999f4c6");//P_00035
        // String secureToken = generateHMAC(val,"9392c19853c24bceb948c4c5343a1e60");//wep

         // String secureToken = generateHMAC(val,"abc");
        String secureToken = generateHMAC(val,hashKey);//AM_00004
        //String secureToken = generateHMAC(val,"f1b9b9b8a7d24bd1afc84871fa65532f");//wep P_00009
       // System.out.println("Token string2="+secureToken);
        return secureToken;
    }
      private String getSecureTokenagg(String amt,String currencyCode,String aggMerchantId,String orderId) {
       // Toast.makeText(this.cordova.getActivity().getApplicationContext(),amt,Toast.LENGTH_LONG).show();
        DecimalFormat df = new DecimalFormat();
        df.setMinimumFractionDigits(2);
        Float f = Float.parseFloat(amt);
        df.format(f);
        amt = String.format("%.2f", f);

        String val = null;
       
       // val = amt + currencyCode + merchantId + orderId;
        val = aggMerchantId + amt + currencyCode + orderId;
       
       //Toast.makeText(this.cordova.getActivity().getApplicationContext(),val,Toast.LENGTH_LONG).show();
        //System.out.println("val "+val);
      //  String secureToken = generateHMAC(val, "0f7c5df1a9b94d90ae09d6010999f4c6");//P_00035
        // String secureToken = generateHMAC(val,"9392c19853c24bceb948c4c5343a1e60");//wep

         // String secureToken = generateHMAC(val,"abc");
        String secureToken = generateHMAC(val,hashKey);//AM_00004
        //String secureToken = generateHMAC(val,"f1b9b9b8a7d24bd1afc84871fa65532f");//wep P_00009
       // System.out.println("Token string2="+secureToken);
        return secureToken;
    }

}
