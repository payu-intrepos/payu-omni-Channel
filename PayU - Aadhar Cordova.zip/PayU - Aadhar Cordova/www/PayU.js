var exec = require('cordova/exec');

exports.coolMethod = function (arg0, success, error) {
    exec(success, error, 'PayU', 'coolMethod', [arg0]);
};
exports.init = function(arg0,arg1,arg2,arg3,arg4,arg5,success,error){
    exec(success, error, 'PayU','init',[arg0,arg1,arg2,arg3,arg4,arg5]);
}

exports.makePayment = function(arg0,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,success,error){
    exec(success, error, 'PayU','makePayment',[arg0,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9])
}